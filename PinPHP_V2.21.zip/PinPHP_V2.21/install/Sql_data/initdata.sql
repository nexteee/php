--
-- 数据库: `pinphp2.21`
--

--
-- 转存表中的数据 `pp_access`
--

INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 14);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 13);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 12);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 50);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 51);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 99);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 100);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 101);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 102);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 103);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 104);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 107);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 115);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 116);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 117);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 118);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 121);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 122);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 15);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 16);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 101);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 102);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 103);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 105);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 106);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 117);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 50);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 51);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 99);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 100);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 101);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 102);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 103);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 104);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 107);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 115);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 116);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 117);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 118);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 121);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 122);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(1, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 116);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 115);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 110);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 109);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 108);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 107);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 104);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 106);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 105);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 103);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 102);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 101);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 100);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 99);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 51);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 50);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 124);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 123);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 125);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 16);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 15);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 14);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 13);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 12);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 11);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 122);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 121);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 10);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 9);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 8);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 118);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 7);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 6);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 5);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 4);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 3);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 2);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 1);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);
INSERT INTO `pp_access` (`role_id`, `node_id`) VALUES(2, 127);

--
-- 转存表中的数据 `pp_ad`
--

INSERT INTO `pp_ad` (`id`, `board_id`, `type`, `name`, `url`, `code`, `start_time`, `end_time`, `clicks`, `add_time`, `ordid`, `status`) VALUES(6, 4, 'code', '麦包包', '', '<script type=\\"text/javascript\\">var _bdhmProtocol = ((\\"https:\\" == document.location.protocol) ? \\" https://\\" : \\" http://\\");document.write(unescape(\\"%3Cscript src=\\''\\" + _bdhmProtocol + \\"hm.baidu.com/h.js%3F0d7cfb59679455d9e770b1f9e1487bdf\\'' type=\\''text/javascript\\''%3E%3C/script%3E\\"));</script>', 1333595088, 1365217491, 0, 1333681516, 0, 1);
INSERT INTO `pp_ad` (`id`, `board_id`, `type`, `name`, `url`, `code`, `start_time`, `end_time`, `clicks`, `add_time`, `ordid`, `status`) VALUES(7, 5, 'code', '凡客', '', '<a href="http://c.duomai.com/track.php?sid=10506&lid=2178&aid=62&euid=&t=http%3A%2F%2Fcatalog.vancl.com%2Fintegrated%2Fgzcs_20120224.html" target="_blank"><img border="0" src="http://www.duomai.com/Public/Uploads/d5755cdbca7ca21daccf62114f129dba.gif" alt="格子衬衫 79元起" /></a>', 1333683143, 1365219146, 11, 1333683151, 0, 1);

--
-- 转存表中的数据 `pp_adboard`
--

INSERT INTO `pp_adboard` (`id`, `name`, `type`, `width`, `height`, `description`, `status`) VALUES(1, '首页焦点图', 'focus', 580, 280, '33', 1);
INSERT INTO `pp_adboard` (`id`, `name`, `type`, `width`, `height`, `description`, `status`) VALUES(4, '详细页横幅', 'banner', 950, 100, '', 1);
INSERT INTO `pp_adboard` (`id`, `name`, `type`, `width`, `height`, `description`, `status`) VALUES(5, '详细页右侧', 'banner', 226, 226, '', 1);
INSERT INTO `pp_adboard` (`id`, `name`, `type`, `width`, `height`, `description`, `status`) VALUES(6, '首页下方横幅', 'banner', 950, 100, '', 1);

--
-- 转存表中的数据 `pp_album_cate`
--

INSERT INTO `pp_album_cate` (`id`, `title`, `add_time`, `album_num`, `sort_order`, `status`) VALUES(5, '其他', 1338789120, 0, 0, 1);
INSERT INTO `pp_album_cate` (`id`, `title`, `add_time`, `album_num`, `sort_order`, `status`) VALUES(1, '美容', 1338789120, 0, 1, 1);
INSERT INTO `pp_album_cate` (`id`, `title`, `add_time`, `album_num`, `sort_order`, `status`) VALUES(2, '购物', 1338789120, 0, 1, 1);
INSERT INTO `pp_album_cate` (`id`, `title`, `add_time`, `album_num`, `sort_order`, `status`) VALUES(3, '生活', 1338789120, 0, 5, 1);
INSERT INTO `pp_album_cate` (`id`, `title`, `add_time`, `album_num`, `sort_order`, `status`) VALUES(4, '家居', 1338789120, 0, 10, 1);

--
-- 转存表中的数据 `pp_article`
--

INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(1, 1, '关于我们', '', '', '', '', '<div>　　欢迎来到PinPHP－拼命网， 拼命网&nbsp;是一个技术驱动创造时尚的互联网创业型公司，通过搜索引擎、图形处理、视觉搜索等核心技术研发优势，为中国千百万的个人站长提供一个解决如何快速抢建一个社会化的电子商务导购平台，它可以帮助爱美丽的女生找到适合的穿衣搭配、在哪里购买合适的时装搭配网购社区平台；我们将致力于为每一个时尚女孩都能轻松地创建属于自己的搭配宝典库而矢志不移的奉献青春年华。</div>\r\n<div><br />\r\n</div>\r\n<div>　　来逛 拼命网&nbsp;，你将发现更多喜爱的搭配风格，找到你最喜欢的时尚元素，你也将发现全球各地流行的风格与趋势，你还能很方便的在线拼贴搭配出你的时尚品味；懂得搭配的女人才更美丽，拉上你的好姐妹们一起来逛美丽街吧！</div>\r\n<div><br />\r\n</div>\r\n<div>　　Logo寓意诠释：化蛹成碟的美丽蜕变，意思是通过来逛 拼命网能让女孩们蜕变得更美丽！</div>', '2012-03-17 11:30:14', 0, 0, 0, 1, '', '', '');
INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(2, 1, '网站地图', '', '', '', '', '网站地图<br />', '2012-03-17 11:31:22', 0, 0, 0, 1, '', '', '');
INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(3, 1, '联系我们', '', '', '', '', '<p>联系电话：0571-28058597</p>\r\n<p>&nbsp;</p>\r\n<p>官方网站：www.pinphp.com</p>\r\n<p>&nbsp;</p>\r\n<p>地址：杭州市万塘路６９号华星科技苑Ａ楼</p>\r\n<p>&nbsp;</p>\r\n<p>邮编：３１００１２</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', '2012-03-17 11:32:08', 0, 0, 0, 1, '', '', '');
INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(4, 1, '隐私政策', '', '', '', '拼品网', '<div style="text-align:center;"><b><span style="font-size:18px;">隐私保护原则</span></b> </div>\r\n<div>　　我们非常重视您的隐私，保护用户隐私是美丽说的重点原则，在您使用美丽说提供的服务前，请您仔细阅读以下隐私保护原则。</div>\r\n<div><br />\r\n</div>\r\n<div>　　<b>一、用户信息</b></div>\r\n<div>　　美丽说将对您所提供的资料进行严格的管理及保护，美丽说通过技术手段、提供隐私保护服务功能、强化内部管理等办法充分保护用户的个人资料安全。美丽说为用户提供对个人注册信息的绝对的控制权，用户可以通过“修改个人信息”查看或修改个人信息。用户自愿注册个人信息，用户在注册时提供的所有信息，都是基于自愿，用户有权在任何时候拒绝提供这些信息。美丽说保证不对外公开或向第三方提供用户注册的个人资料，及用户在使用服务时存储的非公开内容，但下列情况除外：</div>\r\n<div>　　◇ 事先获得您的明确授权；</div>\r\n<div>　　◇ 根据有关的法律法规要求；</div>\r\n<div>　　◇ 按照相关司法机构或政府主管部门的要求；</div>\r\n<div>　　◇ 只有透露你的个人资料，才能提供你所要求的产品和服务；</div>\r\n<div>　　◇ 因黑客行为或用户的保管疏忽导致帐号、密码遭他人非法使用；</div>\r\n<div>　　◇ 由于您将用户密码告知他人或与他人共享注册帐户，由此导致的任何个人资料泄露。</div>\r\n<div><br />\r\n</div>\r\n<div>　　<b>二、Cookies和其他浏览器技术</b></div>\r\n<div>　　当用户访问美丽说的时候，我们可能会保存会员的用户登录状态并且为用户分配一个或多个“Cookies”（一个很小的文本文件），例如：当会员访问一个需要会员登录才可以提供的信息或服务，当会员登录时，我们会把该会员的登录名和密码加密存储在用会员计算机的Cookie文件中，由于是不可逆转的加密存储，其他人即使可以使用该会员的计算机，也无法识别出会员的用户名和密码。会员并不需要额外做任何工作，所有的收集和保存都由系统自动完成。</div>\r\n<div>Cookie文件将永久的保存在您的计算机硬盘上，除非您使用浏览器或操作系统软件手工将其删除。您也可以选择“不使用Cookie”或“在使用Cookie时事先通知我”的选项禁止Cookie的产生，但是您将为此无法使用一些美丽说的查询和服务。</div>\r\n<div><br />\r\n</div>\r\n<div>　　<b>三、合作伙伴</b></div>\r\n<div>　　我们选择有信誉的第三方公司或网站作为我们的合作伙伴为用户提供信息和服务。尽管我们只选择有信誉的公司或网站作为我们的合作伙伴，但是每个合作伙伴都会有与美丽说不同的隐私保护政策，一旦您通过点击进入了合作伙伴的网站，美丽说隐私保护原则将不再生效，我们　　建议您查看该合作伙伴网站的隐私条款，并了解该合作伙伴对于收集、使用、泄露您的个人信息的规定。</div>\r\n<div>　　</div>\r\n<div>　　如果您对此隐私保护原则有任何疑问或建议，请通过以下方式联系我们: tech@pinphp.com，我们会尽一切努力保护您的隐私。</div>', '2012-03-17 11:33:00', 0, 0, 0, 1, '', '', '');
INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(5, 5, '新手指南', '', '', '', '', '新手指南<br />', '2012-03-17 11:33:29', 0, 0, 0, 1, '', '', '');
INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(6, 5, '网站地图', '', '', '', '', '新手指南<br />', '2012-03-17 11:33:45', 0, 0, 0, 1, '', '', '');
INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(7, 9, '50条天使之恋项链免费申领', '', '4f640f80f14d9.jpg', '', '白色情人节来啦，浪漫延续，美丽说携手@珂兰钻石网 为爱美丽们准备了50条天使之恋项链，这个情人节让@珂兰钻石网 陪你一起度过，妞们还等什么，快来申领吧！', '', '2012-03-17 12:13:53', 0, 0, 0, 1, '', '', '');
INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(8, 9, '100件Shinelove心爱FOR LOVER文胸免费试穿', '', '4f640fe112c89.jpg', 'index.php?m=search&a=index&type=search&keywords=心爱', '#100件心爱文胸试穿申领#有心才有爱，把爱传至心底，爱美丽们一定要学会宠爱自己哦！美丽说携手 @Shinelove心爱 为爱美丽们准备了100件爱慕集团旗下网络专享品牌“Shinelove心爱” 文胸。', '', '2012-03-17 12:15:29', 0, 0, 0, 1, '', '', '');
INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(9, 9, '50件金三塔真丝家居服免费试穿', '', '', 'index.php?m=search&a=index&type=search&keywords=家居', '50件金三塔真丝家居服免费试穿50件金三塔真丝家居服免费试穿50件金三塔真丝家居服免费试穿50件金三塔真丝家居服免费试穿50件金三塔真丝家居服免费试穿', '', '2012-03-17 12:15:49', 0, 0, 0, 1, '', '', '');
INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(10, 9, '100套大牌护肤盒子免费试用', '', '', 'http://demo.pinphp.com/c-2', '100套大牌护肤盒子免费试用100套大牌护肤盒子免费试用100套大牌护肤盒子免费试用100套大牌护肤盒子免费试用', '', '2012-03-17 12:16:01', 0, 0, 0, 1, '', '', '');
INSERT INTO `pp_article` (`id`, `cate_id`, `title`, `orig`, `img`, `url`, `abst`, `info`, `add_time`, `ordid`, `is_hot`, `is_best`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(11, 9, '女生节小精灵有礼相送', '', '4f64199e548b1.jpg', 'index.php?m=search&a=index&type=search&keywords=女生', '2 女生节小精灵有礼相送2 女生节小精灵有礼相送2 女生节小精灵有礼相送2 女生节小精灵有礼相送', '', '2012-03-17 12:16:33', 0, 1, 1, 1, '', '', '');

--
-- 转存表中的数据 `pp_article_cate`
--

INSERT INTO `pp_article_cate` (`id`, `name`, `alias`, `pid`, `status`, `article_nums`, `sort_order`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(1, '网站信息', 'sites', 11, 1, 4, 10, '', '', '');
INSERT INTO `pp_article_cate` (`id`, `name`, `alias`, `pid`, `status`, `article_nums`, `sort_order`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(5, '新手入门', 'faq', 11, 1, 2, 5, '', '', '');
INSERT INTO `pp_article_cate` (`id`, `name`, `alias`, `pid`, `status`, `article_nums`, `sort_order`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(9, '热门活动', 'active', 10, 1, 5, 0, '', '', '');
INSERT INTO `pp_article_cate` (`id`, `name`, `alias`, `pid`, `status`, `article_nums`, `sort_order`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(10, '资讯活动', 'news', 0, 1, 0, 1, '', '', '');
INSERT INTO `pp_article_cate` (`id`, `name`, `alias`, `pid`, `status`, `article_nums`, `sort_order`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(11, '网站帮助', 'help', 0, 1, 0, 2, '', '', '');

--
-- 转存表中的数据 `pp_flink`
--

INSERT INTO `pp_flink` (`id`, `cate_id`, `img`, `name`, `url`, `status`, `ordid`) VALUES(1, 1, '', 'B2C商城', 'http://www.dob2c.com/', 1, 99);
INSERT INTO `pp_flink` (`id`, `cate_id`, `img`, `name`, `url`, `status`, `ordid`) VALUES(2, 1, '', 'PinPHP官网', 'http://www.pinphp.com', 1, 99);
INSERT INTO `pp_flink` (`id`, `cate_id`, `img`, `name`, `url`, `status`, `ordid`) VALUES(3, 1, '', '美贝网', 'http://www.meibei.com', 1, 99);
INSERT INTO `pp_flink` (`id`, `cate_id`, `img`, `name`, `url`, `status`, `ordid`) VALUES(4, 2, '', '逛－发现喜欢', 'http://www.guang.com', 1, 99);

--
-- 转存表中的数据 `pp_flink_cate`
--

INSERT INTO `pp_flink_cate` (`id`, `name`) VALUES(1, '友情链接');
INSERT INTO `pp_flink_cate` (`id`, `name`) VALUES(2, '合作伙伴');

--
-- 转存表中的数据 `pp_focus`
--

INSERT INTO `pp_focus` (`id`, `cate_id`, `title`, `url`, `img`, `abst`, `clicks`, `ordid`, `status`) VALUES(9, 1, '中性风潮', '?a=index&m=cate&cid=3', '4f7d43c7e4e98.png', '', 146, 0, 0);
INSERT INTO `pp_focus` (`id`, `cate_id`, `title`, `url`, `img`, `abst`, `clicks`, `ordid`, `status`) VALUES(10, 1, '格子控女生', '?a=index&m=cate&cid=5', '4f7d439f15ab3.png', '', 96, 0, 1);
INSERT INTO `pp_focus` (`id`, `cate_id`, `title`, `url`, `img`, `abst`, `clicks`, `ordid`, `status`) VALUES(7, 1, '蝴蝶结公主', '?a=index&m=cate&cid=7', '4f7d56a8e5540.png', '', 88, 0, 1);
INSERT INTO `pp_focus` (`id`, `cate_id`, `title`, `url`, `img`, `abst`, `clicks`, `ordid`, `status`) VALUES(8, 1, '爱上小碎花', '?a=index&m=cate&cid=1', '4f7d57352e630.png', '', 90, 0, 1);

--
-- 转存表中的数据 `pp_focus_cate`
--

INSERT INTO `pp_focus_cate` (`id`, `name`, `width`, `height`) VALUES(1, '首页焦点', 580, 280);

--
-- 转存表中的数据 `pp_group`
--

INSERT INTO `pp_group` (`id`, `name`, `title`, `create_time`, `update_time`, `status`, `sort`) VALUES(1, 'system', '系统设置', 1222841259, 1222841259, 1, 3);
INSERT INTO `pp_group` (`id`, `name`, `title`, `create_time`, `update_time`, `status`, `sort`) VALUES(4, 'article', '内容管理', 1222841259, 1222841259, 1, 1);
INSERT INTO `pp_group` (`id`, `name`, `title`, `create_time`, `update_time`, `status`, `sort`) VALUES(6, 'goods', '商品管理', 1222841259, 0, 1, 0);
INSERT INTO `pp_group` (`id`, `name`, `title`, `create_time`, `update_time`, `status`, `sort`) VALUES(8, 'member', '会员管理', 0, 0, 1, 2);

--
-- 转存表中的数据 `pp_items_cate`
--

INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(1, '衣服', NULL, 0, 2, 993, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(2, '鞋子', NULL, 0, 0, 0, 0, 0, '', 0, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(3, '包包', NULL, 0, 0, 0, 0, 0, '', 0, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(4, '配饰', NULL, 0, 0, 0, 0, 0, '', 0, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(5, '美容', NULL, 0, 0, 0, 0, 0, '', 0, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(6, '家居', NULL, 0, 0, 0, 0, 0, '', 0, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(7, '当季热款', NULL, 1, 0, 4044, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(8, '当季流行', NULL, 1, 0, 0, 0, 0, '', 0, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(9, '热门风格', NULL, 1, 0, 0, 0, 0, '', 0, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(10, '颜色', NULL, 1, 0, 0, 0, 0, '', 0, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(11, '材质', NULL, 1, 0, 0, 0, 0, '', 0, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(12, '当季热款', NULL, 2, 0, 0, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(13, '当季流行', NULL, 2, 0, 0, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(14, '热门风格', NULL, 2, 0, 0, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(15, '颜色', NULL, 2, 0, 0, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(16, '材质', NULL, 2, 0, 0, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(17, '当季热款', NULL, 3, 0, 0, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(18, '当季热款', NULL, 4, 0, 0, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(19, '功效', NULL, 5, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(20, '家', NULL, 6, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(21, '当季流行', NULL, 3, 0, 4044, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(22, '当季流行', NULL, 4, 0, 0, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(23, '护肤', NULL, 5, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(24, '起居室', NULL, 6, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(326, '耳钉', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(26, '热门风格', NULL, 4, 0, 0, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(27, '彩妆', NULL, 5, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(28, '卧室', NULL, 6, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(325, '手表', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(30, '元素', NULL, 4, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(31, '美体', NULL, 5, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(32, '厨房', NULL, 6, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(33, '材质', NULL, 3, 0, 0, 0, 0, '', 1, 1, '', '', NULL, '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(324, '项链', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(35, '热门品牌', NULL, 5, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(36, '卫浴', NULL, 6, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(37, '连衣裙', NULL, 7, 0, 445, 1340871556, 10, '', 1, 1, '', '', '#ee1d24', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(38, '衬衫', NULL, 7, 0, 10627, 1342845101, 30, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(39, 'T恤', NULL, 7, 0, 756118, 1340876264, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(40, '牛仔裤', NULL, 7, 0, 6, 1341628897, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(41, '开衫', NULL, 7, 0, 0, 1341628933, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(42, '情侣装', NULL, 7, 0, 2, 1341629052, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(43, '短裙', NULL, 7, 0, 101683, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(44, '马甲', NULL, 7, 0, 0, 1342845108, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(45, '蕾丝', NULL, 8, 0, 0, 1342672152, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(46, '豹纹', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(47, '条纹', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(48, '欧美', NULL, 9, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(49, '日系', NULL, 9, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(50, '甜美', NULL, 9, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(51, 'OL', NULL, 9, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(52, '民族', NULL, 9, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(53, '白色', NULL, 10, 0, 83054, 1342763175, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(54, '宝蓝', NULL, 10, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(55, '黄色', NULL, 10, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(56, '黑色', NULL, 10, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(57, '奶油色', NULL, 10, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(58, '红色', NULL, 10, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(59, '裸色', NULL, 10, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(60, '牛仔', NULL, 11, 0, 186964, 1342763254, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(61, '针织', NULL, 11, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(62, '纯棉', NULL, 11, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(63, '丝绸', NULL, 11, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(64, '雪纺衫', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(65, '吊带', NULL, 7, 0, 175763, 1342845322, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(66, '长裙', NULL, 7, 0, 43808, 1342847555, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(67, '小脚裤', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(68, '打底衫', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(69, '背心', NULL, 7, 0, 12743, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(70, '连体裤', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(71, '半身裙', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(72, '短裤', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(73, '礼服', NULL, 7, 0, 0, 1340874867, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(74, '牛仔短裤', NULL, 7, 0, 0, 1340875212, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(75, '防晒衣', NULL, 7, 0, 0, 1340875359, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(76, '罩衫', NULL, 7, 0, 25, 1341331712, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(77, '背带裤', NULL, 7, 0, 1, 1341628695, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(78, '背心裙', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(79, '九分裤', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(80, '蓬蓬裙', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(81, '打底裤', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(82, '哈伦裤', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(83, '阔腿裤', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(84, '包臀裙', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(85, '裙裤', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(86, '运动裤', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(87, '高腰裤', NULL, 7, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(88, '雪纺', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(89, '名媛', NULL, 8, 0, 0, 1342678681, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(90, '娃娃领', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(91, '露肩', NULL, 8, 0, 0, 1342678670, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(92, '碎花', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(93, '镂空', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(94, '蝴蝶结', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(95, '铆钉', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(96, '透视', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(97, '泡泡袖', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(98, '纯色', NULL, 8, 0, 0, 1340874260, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(99, '波点', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(100, '几何', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(101, '印花', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(102, '撞色', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(103, '渐变', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(104, '格子', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(105, '波普', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(106, 'Boyfriend', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(107, 'Oversize', NULL, 8, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(108, '高街', NULL, 9, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(109, '复古', NULL, 9, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(110, '英伦', NULL, 9, 0, 0, 1342863025, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(111, '性感', NULL, 9, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(112, '个性', NULL, 9, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(113, '优雅', NULL, 9, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(114, '薄荷绿', NULL, 10, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(115, '粉色', NULL, 10, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(116, '玫红', NULL, 10, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(117, '绿色', NULL, 10, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(118, '单鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(119, '人字拖', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(120, '高跟鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(121, '平底鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(122, '鱼嘴鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(123, '凉鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(124, '粗跟鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(125, '细跟鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(126, '雨鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(127, '厚底鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(128, '复古鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(129, '编织凉鞋', NULL, 12, 0, 1, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(130, '豆豆鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(131, '系带鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(132, '休闲鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(133, '帆布鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(134, '松糕鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(135, '坡跟鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(136, '罗马鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(137, '运动鞋', NULL, 12, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(138, '系带', NULL, 13, 0, 1, 1340876283, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(139, '坡跟', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(140, '波点', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(141, '铆钉', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(142, '蝴蝶结', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(143, '粗跟', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(144, '尖头', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(145, '防水台', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(146, '拼接', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(147, '动物纹', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(148, '豹纹', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(149, '流苏', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(150, '玛丽珍鞋', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(151, '保暖', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(152, '方头', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(153, '厚底', NULL, 13, 0, 1, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(154, '碎花', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(155, '细跟', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(156, '条纹', NULL, 13, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(157, '男孩', NULL, 14, 0, 14434, 1342763293, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(158, '复古', NULL, 14, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(159, '英伦', NULL, 14, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(160, '甜美', NULL, 14, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(161, '朋克', NULL, 14, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(162, '性感', NULL, 14, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(163, '欧美', NULL, 14, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(164, '日系', NULL, 14, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(165, '优雅', NULL, 14, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(166, '学院', NULL, 14, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(167, '白的', NULL, 15, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(168, '亮色', NULL, 15, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(169, '裸色', NULL, 15, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(170, '纯色', NULL, 15, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(171, '米色', NULL, 15, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(172, '黑色', NULL, 15, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(173, '宝蓝', NULL, 15, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(174, '红色', NULL, 15, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(175, '金色', NULL, 15, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(176, '玫红', NULL, 15, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(177, '皮革', NULL, 16, 0, 0, 1342678697, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(178, '帆布', NULL, 16, 0, 79300, 1342678878, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(179, '漆皮', NULL, 16, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(180, '亮皮', NULL, 16, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(181, 'PU', NULL, 16, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(182, '牛仔', NULL, 16, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(183, '棉麻', NULL, 16, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(184, '真丝', NULL, 16, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(185, '透明', NULL, 16, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(186, '花园', NULL, 6, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(187, '小物', NULL, 6, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(188, '美白', NULL, 19, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(189, '保湿', NULL, 19, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(190, '祛痘', NULL, 19, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(191, '抗敏', NULL, 19, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(192, '遮瑕', NULL, 19, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(193, '祛斑', NULL, 19, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(194, '控油', NULL, 19, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(195, '补水', NULL, 19, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(196, '去黑头', NULL, 19, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(197, '收毛孔', NULL, 19, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(198, '去眼袋', NULL, 19, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(199, '防晒霜', NULL, 23, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(200, '喷雾', NULL, 23, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(201, '卸妆油', NULL, 23, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(202, '洗面奶', NULL, 23, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(203, '面膜', NULL, 23, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(204, '眼霜', NULL, 23, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(205, '化妆水', NULL, 23, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(206, '面霜', NULL, 23, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(207, '隔离霜', NULL, 23, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(208, '吸油面纸', NULL, 23, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(209, '药妆', NULL, 23, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(210, '香水', NULL, 27, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(211, '指甲油', NULL, 27, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(212, '睫毛膏', NULL, 27, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(213, 'BB霜', NULL, 27, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(214, '粉饼', NULL, 27, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(215, '蜜粉', NULL, 27, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(216, '口红', NULL, 27, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(217, '腮红', NULL, 27, 0, 546, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(218, '眼影', NULL, 27, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(219, '眉笔', NULL, 27, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(220, '唇彩', NULL, 27, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(221, '眼线膏', NULL, 27, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(222, '手工皂', NULL, 31, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(223, '沐浴露', NULL, 31, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(224, '美颈霜', NULL, 31, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(225, '身体乳', NULL, 31, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(226, '护手霜', NULL, 31, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(227, '假发', NULL, 31, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(228, '发蜡', NULL, 31, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(229, '弹力素', NULL, 31, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(230, '发膜', NULL, 31, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(231, '蓬蓬粉', NULL, 31, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(232, '染发膏', NULL, 31, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(233, '倩碧', NULL, 35, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(234, 'kose', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(235, '雅漾', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(236, '资生堂', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(237, 'DHC', NULL, 35, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(238, '丝芙兰', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(239, 'Benefit', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(240, '植村秀', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(241, 'the face shop', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(242, 'MAC', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(243, '科颜氏', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(244, 'OPI', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(245, '欧舒丹', NULL, 35, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(246, '书柜', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(247, '烛台', NULL, 20, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(248, '墙贴', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(249, '摆件', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(250, '桌布', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(251, '落地灯', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(252, '台灯', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(253, '时钟', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(254, '吊灯', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(255, '吸顶灯', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(256, '杯子', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(257, '置物架', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(258, '香薰', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(259, '地毯', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(260, '收纳', NULL, 20, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(261, '沙发', NULL, 24, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(262, '茶几', NULL, 24, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(263, '搁板', NULL, 24, 0, 0, 0, 0, '', 1, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(264, '电视柜', NULL, 24, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(265, '椅子', NULL, 24, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(266, '桌子', NULL, 24, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(267, '坐垫', NULL, 24, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(268, '沙发垫', NULL, 24, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(269, '照片墙', NULL, 24, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(270, '相框', NULL, 24, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(271, '靠垫', NULL, 24, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(272, '床上用品', NULL, 28, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(273, '床', NULL, 28, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(274, '床头柜', NULL, 28, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(275, '衣柜', NULL, 28, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(276, '斗柜', NULL, 28, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(277, '窗帘', NULL, 28, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(278, '家居鞋', NULL, 28, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(279, '梳妆', NULL, 28, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(280, '盘碟', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(281, '水壶', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(282, '茶具', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(283, '勺', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(284, '筷子', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(285, '饭盒', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(286, '锅具', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(287, '烘焙', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(288, '烹饪', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(289, '储物罐', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(290, '调味瓶', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(291, '餐垫', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(292, '餐巾', NULL, 32, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(293, '毛巾', NULL, 36, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(294, '浴帘', NULL, 36, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(295, '浴室套件', NULL, 36, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(296, '皂液器', NULL, 36, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(297, '浴室垫', NULL, 36, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(298, '皂盒', NULL, 36, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(299, '衣架', NULL, 36, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(300, '马桶刷', NULL, 36, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(301, '挂钩', NULL, 36, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(302, '花瓶', NULL, 186, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(303, '仿真花', NULL, 186, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(304, '园艺工具', NULL, 186, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(305, '迷你植物', NULL, 186, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(306, '水培', NULL, 186, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(307, '多肉植物', NULL, 186, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(308, '花架', NULL, 186, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(309, '花盆', NULL, 186, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(310, '盆栽', NULL, 186, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(311, '遮阳伞', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(312, '手机壳', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(313, '马克杯', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(314, '加湿器', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(315, '风扇', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(316, '首饰盒', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(317, '抱枕', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(318, '贴纸', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(319, '玩偶', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(320, 'LOMO', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(321, '文具', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(322, '本子', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(323, '钥匙扣', NULL, 187, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(327, '发箍', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(328, '耳环', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(329, '手链', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(330, '钥匙链', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(331, '细腰带', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(332, '发圈', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(333, '墨镜', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(334, '戒指', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(335, '胸针', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(336, '镜框', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(337, '丝袜', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(338, '腰带', NULL, 18, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(339, '发带', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(340, '袜套', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(341, '军帽', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(342, '草帽', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(343, '吊坠', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(344, '锁骨链', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(345, '头巾', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(346, '假领', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(347, '草编帽', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(348, '遮阳帽', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(349, '宽沿帽', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(350, '怀表', NULL, 22, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(351, '日系', NULL, 26, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(352, '个性', NULL, 26, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(353, '朋克', NULL, 26, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(354, '摇滚', NULL, 26, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(355, '欧美', NULL, 26, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(356, '玉', NULL, 30, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(357, '印花', NULL, 30, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(358, '银饰', NULL, 30, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(359, '镶钻', NULL, 30, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(360, '水晶', NULL, 30, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(361, '蕾丝', NULL, 30, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(362, '羽毛', NULL, 30, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(363, '24k金', NULL, 30, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(364, '花朵', NULL, 30, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(365, '玫瑰金', NULL, 30, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(366, '编织包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(367, '钱包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(368, '方扣包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(369, '斜挎包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(370, '化妆包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(371, '果冻包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(372, '单肩包', NULL, 17, 0, 0, 1340871525, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(373, '双肩包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(374, '手拿包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(375, '手提包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(376, '复古包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(377, '零钱包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(378, '帆布包 ', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(379, '水桶包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(380, '链条包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(381, '晚宴包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(382, '环保袋', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(383, '行李箱', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(384, '机车包', NULL, 17, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(385, '流苏', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(386, '撞色', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(387, '外贸', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(388, '环保', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(389, '拼接', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(390, '豹纹', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(391, '链条', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(392, '蝴蝶结', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(393, '铆钉', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(394, '水钻', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(395, '复古', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(396, '菱形格', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(397, '代购', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(398, '几何', NULL, 21, 0, 54, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(399, '甜美', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(400, '动物纹', NULL, 21, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(401, '帆布', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(402, 'PU', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(403, '羊皮', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(404, '牛仔', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(405, '漆皮', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(406, '仿皮', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(407, '牛皮', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(408, '棉麻', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(409, '肌理', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(410, '亮皮', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');
INSERT INTO `pp_items_cate` (`id`, `name`, `img`, `pid`, `item_nums`, `item_likes`, `collect_time`, `ordid`, `tags`, `is_hots`, `status`, `seo_title`, `seo_keys`, `color`, `seo_desc`) VALUES(411, '皮革', NULL, 33, 0, 0, 0, 0, '', 0, 1, '', '', '', '');

--
-- 转存表中的数据 `pp_items_site`
--

INSERT INTO `pp_items_site` (`id`, `name`, `alias`, `site_domain`, `site_logo`, `collect_url`, `collect_time`, `item_nums`, `type`, `is_dels`) VALUES(1, '淘宝', 'taobao', 'http://item.taobao.com,http://item.tmall.com', 'taobao.jpg', '', 0, 0, 1, 1);
INSERT INTO `pp_items_site` (`id`, `name`, `alias`, `site_domain`, `site_logo`, `collect_url`, `collect_time`, `item_nums`, `type`, `is_dels`) VALUES(2, 'PinPHP', 'handel', 'http://www.pinphp.com', 'pinphp.jpg', '', 0, 0, 0, 1);

--
-- 转存表中的数据 `pp_nav`
--

INSERT INTO `pp_nav` (`id`, `name`, `alias`, `url`, `sort_order`, `system`, `type`, `in_site`, `is_show`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(1, '逛宝贝', 'cate', '/index.php?m=search', 1, 1, 1, 1, 1, '发现喜欢', '发现喜欢', '发现喜欢');
INSERT INTO `pp_nav` (`id`, `name`, `alias`, `url`, `sort_order`, `system`, `type`, `in_site`, `is_show`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(2, '专辑', 'yifu', '/index.php?m=album&a=index', 2, 1, 1, 1, 1, '专辑', '专辑', '专辑');
INSERT INTO `pp_nav` (`id`, `name`, `alias`, `url`, `sort_order`, `system`, `type`, `in_site`, `is_show`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(3, '衣服', 'xiezi', '/index.php?m=cate&a=index&cid=1', 3, 0, 1, 1, 1, '衣服', '衣服', '衣服');
INSERT INTO `pp_nav` (`id`, `name`, `alias`, `url`, `sort_order`, `system`, `type`, `in_site`, `is_show`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(4, '鞋子', 'baobao', '/index.php?m=cate&a=index&cid=2', 4, 0, 1, 1, 1, '鞋子', '鞋子', '鞋子');
INSERT INTO `pp_nav` (`id`, `name`, `alias`, `url`, `sort_order`, `system`, `type`, `in_site`, `is_show`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(5, '配饰', 'peishi', '/index.php?m=cate&a=index&cid=4', 5, 0, 1, 1, 1, '欧美街', '欧美街', '欧美街');
INSERT INTO `pp_nav` (`id`, `name`, `alias`, `url`, `sort_order`, `system`, `type`, `in_site`, `is_show`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(6, '美容', 'meirong', '/index.php?m=cate&a=index&cid=5', 6, 0, 1, 1, 1, '美容', '美容', '美容');
INSERT INTO `pp_nav` (`id`, `name`, `alias`, `url`, `sort_order`, `system`, `type`, `in_site`, `is_show`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(7, '家居', 'jiaju', '/index.php?m=cate&a=index&cid=6', 7, 0, 2, 1, 1, '淘家居', '淘家居', '淘家居');
INSERT INTO `pp_nav` (`id`, `name`, `alias`, `url`, `sort_order`, `system`, `type`, `in_site`, `is_show`, `seo_title`, `seo_keys`, `seo_desc`) VALUES(10, '包包', 'peishi', '/index.php?m=cate&a=index&cid=3', 5, 0, 1, 1, 1, '欧美街', '欧美街', '欧美街');

--
-- 转存表中的数据 `pp_node`
--

INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(1, 'node', '菜单管理', '', '', '', 1, '', 0, 0, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(2, 'node', '菜单管理', 'index', '菜单列表', '', 1, '', 0, 1, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(3, 'node', '菜单管理', 'add', '添加菜单', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(4, 'node', '菜单管理', 'edit', '编辑菜单', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(5, 'node', '菜单管理', 'delete', '删除菜单', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(6, 'role', '角色管理', '', '', '', 1, '', 370, 0, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(7, 'role', '角色管理', 'index', '角色管理', '', 1, '', 0, 1, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(8, 'role', '角色管理', 'add', '添加角色', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(9, 'role', '角色管理', 'edit', '编辑角色', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(10, 'role', '角色管理', 'delete', '删除角色', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(11, 'role', '角色管理', 'auth', '角色授权', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(12, 'admin', '管理员管理', '', '', '', 1, '', 380, 0, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(13, 'admin', '管理员管理', 'index', '管理员列表', '', 1, '', 0, 1, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(14, 'admin', '管理员管理', 'add', '添加管理员', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(15, 'admin', '管理员管理', 'edit', '编辑管理员', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(16, 'admin', '管理员管理', 'delete', '删除管理员', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(50, 'setting', '网站设置', '', '', '', 1, '', 399, 0, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(51, 'setting', '网站设置', 'index', '网站设置', '', 1, '', 0, 1, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(99, 'flink', '友情链接', '', '', '', 1, '', 98, 0, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(100, 'flink', '友情链接', 'index', '友情链接列表', '', 1, '', 0, 1, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(101, 'article', '资讯管理', '', '', '', 1, '', 100, 0, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(102, 'article', '资讯管理', 'index', '资讯列表', '', 1, '', 0, 1, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(103, 'article', '资讯管理', 'add', '添加资讯', '', 1, '', 0, 1, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(104, 'article_cate', '资讯分类', '', '', '', 1, '', 99, 0, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(105, 'article', '资讯管理', 'edit', '编辑资讯', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(106, 'article', '资讯管理', 'delete', '删除资讯', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(107, 'article_cate', '资讯分类', 'index', '分类列表', '', 1, '', 0, 1, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(108, 'article_cate', '资讯分类', 'add', '添加分类', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(109, 'article_cate', '资讯分类', 'edit', '编辑分类', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(110, 'article_cate', '资讯分类', 'delete', '删除分类', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(115, 'items', '商品管理', '', '', '', 1, '', 0, 0, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(116, 'items', '商品管理', 'index', '商品列表', '', 1, NULL, 0, 1, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(117, 'items_cate', '商品分类', '', NULL, '', 1, NULL, 0, 0, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(118, 'items_cate', '商品分类', 'index', '商品分类', '', 1, NULL, 0, 1, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(134, 'items_tags', '标签管理', 'index', '标签列表', '', 1, '', 0, 1, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(121, 'nav', '导航管理', '', '', '', 1, '', 2, 0, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(122, 'nav', '导航管理', 'index', '导航列表', '', 1, '', 0, 1, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(123, 'nav', '导航管理', 'add', '添加导航', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(124, 'nav', '导航管理', 'edit', '编辑导航', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(125, 'nav', '导航管理', 'delete', '删除导航', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(133, 'items_tags', '标签管理', '', '', '', 1, '', 0, 0, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(132, 'items_cate', '商品管理', 'add', '添加分类', '', 1, '', 0, 1, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(131, 'items', '商品管理', 'add', '添加商品', '5', 1, '', 0, 1, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(135, 'items_collect', '商品采集', '', '', '', 1, '', 0, 0, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(136, 'items_collect', '商品采集', 'index', '商品采集', '', 0, '', 0, 1, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(137, 'items_collect', '商品采集', 'taobaoapi', '淘宝客设置', '', 1, '', 0, 1, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(139, 'adboard', '广告位置', '', '', '', 1, '', 70, 0, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(140, 'adboard', '广告位置', 'index', '广告位置', '', 1, '', 0, 1, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(141, 'ad', '广告管理', '', '', '', 1, '', 90, 0, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(142, 'ad', '广告管理', 'index', '广告列表', '', 1, '', 0, 1, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(143, 'template', '模板管理', '', '', '', 1, '', 0, 0, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(144, 'template', '模板管理', 'index', '模板管理', '', 1, '', 0, 1, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(145, 'items', '商品管理', 'batch_add', '批量添加', '', 1, '', 0, 1, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(146, 'focus', '焦点图管理', 'index', '焦点图列表', '', 1, '', 0, 1, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(147, 'focus', '焦点图管理', 'add', '添加焦点图', '', 1, '', 0, 1, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(148, 'flink', '友情链接', 'add', '添加友情链接', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(149, 'flink', '友情链接', 'edit', '编辑友情链接', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(150, 'flink', '友情链接', 'del', '删除友情链接', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(151, 'ad', '广告管理', 'add', '添加广告', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(152, 'ad', '广告管理', 'edit', '编辑广告', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(153, 'ad', '广告管理', 'delete', '删除广告', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(154, 'adboard', '广告位置', 'add', '添加广告位置', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(155, 'adboard', '广告位置', 'edit', '编辑广告位置', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(156, 'adboard', '广告位置', 'delete', '删除广告位置', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(157, 'focus', '焦点图管理', '', '', '', 1, '', 101, 0, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(158, 'focus', '焦点图管理', 'edit', '编辑焦点图', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(159, 'focus', '焦点图管理', 'delete', '删除焦点图', '', 1, '', 0, 2, 4, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(160, 'items', '商品管理', 'edit', '编辑商品', '', 1, NULL, 0, 2, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(161, 'items', '商品管理', 'delete', '删除商品', '', 1, '', 0, 2, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(162, 'items_cate', '商品管理', 'edit', '编辑分类', '', 1, '', 0, 2, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(163, 'items_cate', '商品管理', 'delete', '删除分类', '', 1, '', 0, 2, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(164, 'items_tags', '标签管理', 'add', '添加标签', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(165, 'items_tags', '标签管理', 'edit', '编辑标签', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(166, 'items_tags', '标签管理', 'delete', '删除标签', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(167, 'items_tags_cate', '关联标签管理', ' ', '', '', 1, '', 0, 0, 6, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(168, 'items_tags_cate', '关联标签管理', 'index', '关联标签列表', '', 1, '', 0, 1, 6, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(169, 'items_tags_cate', '关联标签管理', 'add', '添加关联标签', '', 1, '', 0, 1, 6, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(181, 'items_tags', '标签管理', 'index', '标签列表', '', 1, '', 0, 2, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(171, 'items_tags_cate', '关联标签管理', 'del', '删除关联标签', '', 1, '', 0, 2, 6, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(172, 'items_collect', '商品采集管理', 'edit', '编辑采集设置', '', 1, '', 0, 2, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(173, 'items_collect', '商品采集管理', 'collect', '采集详情列表', '', 1, '', 0, 2, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(174, 'items_collect', '商品采集管理', 'taobao_collect', '采集', '', 1, '', 0, 2, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(177, 'cache', '缓存管理', ' ', '', '', 1, '', 0, 0, 1, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(178, 'cache', '缓存管理', 'index', '缓存管理', '', 1, '', 0, 2, 1, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(179, 'items_collect', '商品采集管理', 'add', '添加来源', '', 1, '', 0, 1, 6, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(180, 'items_collect', '商品采集管理', 'delete', '删除来源', '', 1, '', 0, 1, 6, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(182, 'shop', '商城管理', '', '', '', 1, '', 399, 0, 7, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(183, 'shop', '商城管理', 'index', '商城列表', '', 1, '', 0, 1, 7, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(184, 'shop', '商城管理', 'add', '添加商城', '', 1, '', 0, 1, 7, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(185, 'shop', '商城管理', 'edit', '编辑商城', '', 1, '', 0, 1, 7, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(186, 'shop', '商城管理', 'delete', '删除商城', '', 1, '', 0, 1, 7, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(187, 'shop_cate', '商城类别', '', '', '', 1, '', 399, 0, 7, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(188, 'shop_cate', '商城类别', 'index', '类别列表', '', 1, '', 0, 1, 7, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(189, 'shop_cate', '商城类别', 'add', '添加类别', '', 1, '', 0, 1, 7, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(190, 'shop_cate', '商城类别', 'edit', '编辑类别', '', 1, '', 0, 1, 7, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(191, 'shop_cate', '商城类别', 'delete', '删除类别', '', 1, '', 0, 1, 7, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(192, 'user', '会员管理', '', '', '', 1, '', 399, 0, 8, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(193, 'user', '会员管理', 'index', '会员列表', '', 1, '', 0, 1, 8, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(194, 'user', '会员管理', 'delete', '删除', '', 1, '', 0, 1, 8, 0, 1);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(195, 'items', '商品管理', 'comments', '评论管理', '', 1, '', 0, 1, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(196, 'items', '商品管理', 'collect_by_words', '关键词采集', '', 1, '', 0, 1, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(197, 'setting', '网站设置', 'index', '第三方登录', 'type=oauth', 1, '', 0, 1, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(198, 'setting', '网站设置', 'index', '优化设置', 'type=seo', 1, '', 0, 1, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(199, 'setting', '网站设置', 'index', '关注我们', 'type=guanzhu', 1, '', 0, 1, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(200, 'album', '专辑管理', '', '', '', 1, '', 399, 0, 8, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(201, 'album', '专辑管理', 'index', '专辑列表', '', 1, '', 0, 1, 8, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(202, 'album', '专辑管理', 'edit', '编辑专辑', '', 1, '', 0, 2, 8, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(203, 'album', '专辑管理', 'delete', '删除专辑', '', 1, '', 0, 2, 8, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(204, 'album_cate', '专辑分类管理', 'index', '分类列表', '', 1, '', 0, 1, 8, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(205, 'album_cate', '专辑分类管理', 'add', '添加分类', '', 1, '', 0, 1, 8, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(206, 'album_cate', '专辑分类管理', 'edit', '编辑分类', '', 1, '', 0, 2, 8, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(207, 'album_cate', '专辑分类管理', 'delete', '删除分类', '', 1, '', 0, 2, 8, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(208, 'database', '数据库管理', '', '', '', 1, '', 0, 0, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(209, 'database', '数据库管理', 'execute', '执行', '', 1, '', 0, 1, 1, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(210, 'items', '商品管理', 'delete_search', '一键删除', '', 1, '', 0, 0, 6, 0, 0);
INSERT INTO `pp_node` (`id`, `module`, `module_name`, `action`, `action_name`, `data`, `status`, `remark`, `sort`, `auth_type`, `group_id`, `often`, `is_show`) VALUES(211, 'items_collect', '商品采集', 'collect', '淘宝客采集', 'code=taobao', 1, '', 0, 1, 6, 0, 0);

--
-- 转存表中的数据 `pp_role`
--

INSERT INTO `pp_role` (`id`, `name`, `status`, `remark`, `create_time`, `update_time`) VALUES(1, '管理员', 1, '管理员', 1208784792, 1254325558);
INSERT INTO `pp_role` (`id`, `name`, `status`, `remark`, `create_time`, `update_time`) VALUES(2, '编辑', 1, '编辑', 1208784792, 1254325558);

--
-- 转存表中的数据 `pp_setting`
--

INSERT INTO `pp_setting` (`name`, `data`) VALUES('site_name', 'PinPHP');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('site_title', 'PinPHP');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('site_keyword', 'PinPHP');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('site_description', 'PinPHP');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('site_status', '1');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('site_icp', '浙ICP备88888888号');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('statistics_code', '');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('closed_reason', '网站正在维护中......');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('site_domain', 'http://www.pinphp.com');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('taobao_usernick', '蝎子网');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('taobao_pid', '16185888');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('taobao_appkey', '12504724');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('taobao_appsecret', '9d6877190386092d4288dcae32811081');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('weibo_url', 'http://weibo.com/b2ctime');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('qqweibo_url', '');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('renren_url', '');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('163_url', '');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('qqzone_url', '');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('douban_url', '');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('default_kw', '搜宝贝');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('template', 'default');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('taobao_app_key', '12504724');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('qq_app_key', '100265282');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('qq_app_Secret', 'e23884ea8cb7270700b264463b8168c1');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('sina_app_key', '100265282');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('sina_app_Secret', 'e23884ea8cb7270700b264463b8168c1');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('taobao_app_secret', '9d6877190386092d4288dcae32811081');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('url_model', '0');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('waterfall_sp', '5');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('waterfall_items_num', '5');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('client_hash', '');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('search_words', '欧美,复古,日系,古典');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('index_pins', '1');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('index_album', '1');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('index_items', '2');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('likes_status', '1');
INSERT INTO `pp_setting` (`name`, `data`) VALUES('likes_status', '1');
