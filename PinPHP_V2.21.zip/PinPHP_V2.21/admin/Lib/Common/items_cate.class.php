<?php
class items_cate{
	function test(){
		print_r('go');
	}
}