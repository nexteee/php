<?php 
return array('DEFAULT_THEME'=>'default');