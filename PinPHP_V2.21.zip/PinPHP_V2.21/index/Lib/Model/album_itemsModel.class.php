<?php
class  album_itemsModel extends Model{
	protected $_auto = array (
		array('add_time','time',2,'function'),
	);
}