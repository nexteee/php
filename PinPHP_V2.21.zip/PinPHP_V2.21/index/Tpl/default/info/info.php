<?php
return array(
    'name' => '默认模板',
    'author' => 'PinPHP.com',
    'author_url' => 'http://www.pinphp.com',
    'version' => '2.0',
);
?>
