<?php
return array (
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'pinphp1',
  'DB_USER' => 'root',
  'DB_PWD' => '123456',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'pp_',
  'DEFAULT_THEME' => 'default',
  'TMPL_ACTION_SUCCESS' => 'public:success',
  'TMPL_ACTION_ERROR' => 'public:error',
); 
?>